package domain;

/**
 * @author Victor Divi
 */
public class Aula_Exception extends Exception {
    public Aula_Exception(String message) {
        super(message);
    }
}